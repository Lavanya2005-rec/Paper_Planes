# Blockchain Fraud Logger (ZIP Version)

## 🚀 How to Use

### 1. Deploy Smart Contract

- Open [Remix IDE](https://remix.ethereum.org/)
- Paste the code from `FraudAudit.sol`
- Compile with Solidity `0.8.x`
- Deploy on **Polygon Mumbai** or **Ethereum Goerli** via MetaMask

### 2. Save Deployed Info

- Copy the contract address into `blockchainLogger.js`
- Generate and paste the ABI into `FraudAuditABI.json`

### 3. Setup Node.js Backend

- Run `npm init -y`
- Install Web3: `npm install web3`
- Use `blockchainLogger.js` inside your backend (e.g., Express API)

### 4. Log Fraud Example (Node.js)

```js
const logFraud = require('./blockchainLogger');
logFraud("TX12345", "USER001", "Suspicious amount");
```

## 🔐 Make sure to NEVER expose your private keys in public repos!
