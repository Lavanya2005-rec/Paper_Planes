
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Logo } from '@/components/ui/logo';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  Activity,
  AlertTriangle,
  BarChart3,
  Database,
  User,
  ChevronLeft,
  ChevronRight,
  LogOut,
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const navItems = [
    {
      title: 'Dashboard',
      icon: LayoutDashboard,
      href: '/dashboard',
    },
    {
      title: 'Live Transactions',
      icon: Activity,
      href: '/live-transactions',
    },
    {
      title: 'Fraud Alerts',
      icon: AlertTriangle,
      href: '/fraud-alerts',
    },
    {
      title: 'Analytics',
      icon: BarChart3,
      href: '/analytics',
    },
    {
      title: 'Blockchain Ledger',
      icon: Database,
      href: '/blockchain-ledger',
    },
    {
      title: 'User Profile',
      icon: User,
      href: '/user-profile',
    },
  ];

  return (
    <div
      className={cn(
        'flex flex-col h-screen bg-sidebar border-r border-sidebar-border transition-all duration-300',
        collapsed ? 'w-20' : 'w-64',
        className
      )}
    >
      <div className="p-4 flex items-center justify-between">
        {!collapsed ? (
          <Logo className="text-sidebar-foreground" />
        ) : (
          <Logo variant="small" className="mx-auto text-sidebar-foreground" />
        )}
        {!collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(true)}
            className="text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <ChevronLeft size={18} />
          </Button>
        )}
      </div>
      
      <Separator className="bg-sidebar-border" />

      <div className="flex-1 overflow-y-auto py-4">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 px-3 py-2 rounded-md transition-colors',
                  isActive
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                    : 'text-sidebar-foreground hover:bg-sidebar-accent',
                  collapsed && 'justify-center px-2'
                )
              }
            >
              <item.icon size={20} />
              {!collapsed && <span>{item.title}</span>}
            </NavLink>
          ))}
        </nav>
      </div>
      
      <Separator className="bg-sidebar-border" />
      
      <div className="p-4">
        {collapsed ? (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(false)}
            className="w-full text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <ChevronRight size={18} />
          </Button>
        ) : (
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <LogOut size={18} />
            <span>Logout</span>
          </Button>
        )}
      </div>
    </div>
  );
}
