
import React from 'react';
import { Shield, ShieldCheck, ShieldAlert } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LogoProps {
  variant?: 'default' | 'small' | 'large';
  className?: string;
  animated?: boolean;
}

export function Logo({ variant = 'default', className, animated = false }: LogoProps) {
  const baseSize = variant === 'small' ? 24 : variant === 'large' ? 64 : 36;
  
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div className={cn(
        'relative flex items-center justify-center',
        animated && 'animate-pulse-slow'
      )}>
        <Shield 
          className={cn('text-primary', animated && 'animate-spin-slow')} 
          size={baseSize} 
          strokeWidth={2} 
        />
        <ShieldCheck 
          className="text-safe absolute opacity-60" 
          size={baseSize * 0.7} 
          strokeWidth={2} 
        />
      </div>
      <div className="font-bold tracking-tight">
        <span className="text-primary">Fraud</span>
        <span className="text-blockchain">Shield</span>
      </div>
    </div>
  );
}

export function LogoIcon({ variant = 'default', className, animated = false }: LogoProps) {
  const baseSize = variant === 'small' ? 24 : variant === 'large' ? 64 : 36;
  
  return (
    <div className={cn(
      'relative flex items-center justify-center',
      animated && 'animate-pulse-slow',
      className
    )}>
      <Shield 
        className={cn('text-primary', animated && 'animate-spin-slow')} 
        size={baseSize} 
        strokeWidth={2} 
      />
      <ShieldCheck 
        className="text-safe absolute opacity-60" 
        size={baseSize * 0.7} 
        strokeWidth={2} 
      />
    </div>
  );
}
