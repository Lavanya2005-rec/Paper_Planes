
import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

// Mock data for fraud alerts
const generateMockAlerts = (count: number) => {
  const reasons = [
    'Multiple failed login attempts', 
    'Unusual location', 
    'Transaction pattern anomaly', 
    'Multiple devices', 
    'Large transaction amount'
  ];
  
  const names = ['John Smith', 'Sarah Johnson', 'Michael Brown', 'Emily Davis', 'David Wilson'];
  
  return Array(count).fill(0).map((_, i) => {
    return {
      id: `ALT-${10000 + i}`,
      user: names[Math.floor(Math.random() * names.length)],
      userId: `U-${10000 + Math.floor(Math.random() * 1000)}`,
      amount: `$${(Math.random() * 1000).toFixed(2)}`,
      date: new Date(Date.now() - Math.floor(Math.random() * 604800000)).toLocaleString(),
      reason: reasons[Math.floor(Math.random() * reasons.length)],
      status: Math.random() > 0.3 ? 'pending' : 'resolved'
    };
  });
};

const FraudAlerts = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [alerts] = useState(generateMockAlerts(15));
  const [selectedAlert, setSelectedAlert] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  const handleViewDetails = (alert: any) => {
    setSelectedAlert(alert);
    setDialogOpen(true);
  };
  
  const handleMarkAsResolved = (alert: any) => {
    toast.success(`Alert ${alert.id} marked as resolved`);
    setDialogOpen(false);
  };
  
  const handleBlockUser = (alert: any) => {
    toast.success(`User ${alert.userId} blocked`);
    setDialogOpen(false);
  };
  
  const filteredAlerts = alerts.filter(alert => {
    // Filter by status
    if (statusFilter !== 'all' && alert.status !== statusFilter) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(alert).some(val => 
      val.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-6 w-6 text-destructive" />
                <h1 className="text-3xl font-bold">Fraud Alerts</h1>
              </div>
              
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:flex-auto">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input 
                    placeholder="Search alerts..." 
                    className="pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Flagged Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAlerts.length > 0 ? (
                      filteredAlerts.map((alert) => (
                        <TableRow key={alert.id}>
                          <TableCell className="font-medium">{alert.id}</TableCell>
                          <TableCell>{alert.user}</TableCell>
                          <TableCell>{alert.amount}</TableCell>
                          <TableCell>{alert.date}</TableCell>
                          <TableCell>{alert.reason}</TableCell>
                          <TableCell>
                            <Badge variant={alert.status === 'pending' ? 'outline' : 'default'}>
                              {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button size="sm" variant="outline" onClick={() => handleViewDetails(alert)}>
                                Details
                              </Button>
                              {alert.status === 'pending' && (
                                <Button size="sm" variant="default" onClick={() => handleMarkAsResolved(alert)}>
                                  Resolve
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-4">
                          No fraud alerts found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {selectedAlert && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Fraud Alert Details</DialogTitle>
              <DialogDescription>
                Full information about alert {selectedAlert.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-2 gap-4 py-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Alert ID</p>
                <p>{selectedAlert.id}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <Badge variant={selectedAlert.status === 'pending' ? 'outline' : 'default'}>
                  {selectedAlert.status.charAt(0).toUpperCase() + selectedAlert.status.slice(1)}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">User</p>
                <p>{selectedAlert.user}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">User ID</p>
                <p>{selectedAlert.userId}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Amount</p>
                <p>{selectedAlert.amount}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Date/Time</p>
                <p>{selectedAlert.date}</p>
              </div>
              <div className="col-span-2">
                <p className="text-sm font-medium text-muted-foreground">Reason for Flag</p>
                <p>{selectedAlert.reason}</p>
              </div>
            </div>
            
            <DialogFooter className="flex flex-col sm:flex-row gap-2">
              {selectedAlert.status === 'pending' && (
                <>
                  <Button onClick={() => handleMarkAsResolved(selectedAlert)}>
                    Mark as Resolved
                  </Button>
                  <Button variant="destructive" onClick={() => handleBlockUser(selectedAlert)}>
                    Block User
                  </Button>
                </>
              )}
              <Button variant="outline" onClick={() => setDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default FraudAlerts;
