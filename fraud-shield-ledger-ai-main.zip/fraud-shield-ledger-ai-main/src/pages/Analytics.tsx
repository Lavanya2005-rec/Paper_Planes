
import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, PieChart } from '@/components/ui/chart';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Calendar as CalendarIcon } from 'lucide-react';

const Analytics = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [date, setDate] = useState<Date>();
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  // Generate data for the heat map
  const generateHeatMapData = () => {
    const daysInMonth = 30;
    const labels = Array.from({ length: daysInMonth }, (_, i) => `Day ${i + 1}`);
    
    // Generate random data for safe, suspicious, and fraud transactions
    const safeData = Array.from({ length: daysInMonth }, () => Math.floor(Math.random() * 100));
    const suspiciousData = Array.from({ length: daysInMonth }, () => Math.floor(Math.random() * 50));
    const fraudData = Array.from({ length: daysInMonth }, () => Math.floor(Math.random() * 25));
    
    return {
      labels,
      datasets: [
        {
          label: 'Safe Transactions',
          data: safeData,
          backgroundColor: '#48bb78',
        },
        {
          label: 'Suspicious Transactions',
          data: suspiciousData,
          backgroundColor: '#ed8936',
        },
        {
          label: 'Fraud Transactions',
          data: fraudData,
          backgroundColor: '#e53e3e',
        },
      ],
    };
  };
  
  // Generate data for the fraud type distribution
  const generateFraudTypeData = () => {
    return {
      labels: ['Phishing', 'Identity Theft', 'Account Takeover', 'Credit Card Fraud', 'Payment Fraud', 'Others'],
      datasets: [
        {
          data: [30, 25, 15, 12, 10, 8],
          backgroundColor: ['#48bb78', '#ed8936', '#e53e3e', '#2c7a7b', '#805ad5', '#d53f8c'],
        },
      ],
    };
  };

  // Generate data for the regional breakdown
  const generateRegionalData = () => {
    return {
      labels: ['North America', 'Europe', 'Asia', 'South America', 'Africa', 'Australia'],
      datasets: [
        {
          label: 'Fraud Attempts by Region',
          data: [45, 32, 28, 15, 10, 5],
          backgroundColor: '#2c7a7b',
        },
      ],
    };
  };
  
  // Monthly heat map data
  const heatMapData = generateHeatMapData();
  
  // Fraud type distribution data
  const fraudTypeData = generateFraudTypeData();
  
  // Regional breakdown data
  const regionalData = generateRegionalData();
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <h1 className="text-3xl font-bold">Analytics</h1>
              <div className="flex items-center gap-2">
                <Select defaultValue="month">
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Time Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="quarter">This Quarter</SelectItem>
                    <SelectItem value="year">This Year</SelectItem>
                  </SelectContent>
                </Select>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className="w-36 justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            <Tabs defaultValue="heatmap">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="heatmap">Monthly Heat Map</TabsTrigger>
                <TabsTrigger value="distribution">Fraud Types</TabsTrigger>
                <TabsTrigger value="regional">Regional Analysis</TabsTrigger>
              </TabsList>
              
              <TabsContent value="heatmap">
                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Transaction Heat Map</CardTitle>
                    <CardDescription>
                      Visual representation of transaction volume by day and risk level
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <BarChart data={heatMapData} className="aspect-[3/1] w-full" />
                    <div className="flex justify-center mt-4 gap-8">
                      <div className="flex items-center gap-2">
                        <div className="h-4 w-4 bg-safe rounded-sm"></div>
                        <span className="text-sm">Safe</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-4 w-4 bg-suspicious rounded-sm"></div>
                        <span className="text-sm">Suspicious</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-4 w-4 bg-fraud rounded-sm"></div>
                        <span className="text-sm">Fraud</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="distribution">
                <Card>
                  <CardHeader>
                    <CardTitle>Fraud Type Distribution</CardTitle>
                    <CardDescription>
                      Breakdown of different types of fraud detected
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex justify-center">
                    <div className="w-full max-w-lg">
                      <PieChart data={fraudTypeData} className="aspect-square w-full" />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="regional">
                <Card>
                  <CardHeader>
                    <CardTitle>Regional Fraud Analysis</CardTitle>
                    <CardDescription>
                      Geographical distribution of fraud attempts
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <BarChart data={regionalData} className="aspect-[3/1] w-full" />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
            
            <Card>
              <CardHeader>
                <CardTitle>AI-Powered Insights</CardTitle>
                <CardDescription>
                  Machine learning driven analysis of current trends
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-primary/10 rounded-lg">
                    <h3 className="font-medium text-lg">Anomaly Detection</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Our AI system has detected a 12% increase in phishing attempts targeting mobile banking users. 
                      The pattern suggests coordinated attempts originating from multiple geographic locations.
                    </p>
                  </div>
                  <div className="p-4 bg-primary/10 rounded-lg">
                    <h3 className="font-medium text-lg">Predictive Alert</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Based on historical patterns, we anticipate increased fraud attempts during the upcoming holiday 
                      season. Recommended action: Implement additional verification steps for high-value transactions.
                    </p>
                  </div>
                  <div className="p-4 bg-primary/10 rounded-lg">
                    <h3 className="font-medium text-lg">System Recommendation</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Blockchain ledger analysis shows improved transaction security with reduced false positives 
                      after latest enhancement. Consider expanding implementation to cover all transaction types.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Analytics;
