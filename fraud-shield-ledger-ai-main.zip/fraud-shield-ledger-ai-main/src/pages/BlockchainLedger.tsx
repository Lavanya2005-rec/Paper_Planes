
import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Search, Database, Info } from 'lucide-react';

// Mock data for blockchain ledger
const generateBlockchainData = (count: number) => {
  const transactionTypes = ['Deposit', 'Withdrawal', 'Transfer', 'Payment', 'Exchange'];
  
  return Array(count).fill(0).map((_, i) => {
    const hash = Array(10).fill(0).map(() => Math.random().toString(36).substring(2, 4)).join('');
    
    return {
      id: `BLK-${100000 + i}`,
      timestamp: new Date(Date.now() - Math.floor(Math.random() * 604800000)).toLocaleString(),
      hash: `0x${hash}`,
      prevHash: i > 0 ? `0x${Array(10).fill(0).map(() => Math.random().toString(36).substring(2, 4)).join('')}` : '0x0000000000000000000000',
      txCount: Math.floor(Math.random() * 10) + 1,
      userInfo: `User-${10000 + Math.floor(Math.random() * 1000)}`,
      transactionType: transactionTypes[Math.floor(Math.random() * transactionTypes.length)],
      status: Math.random() > 0.1 ? 'confirmed' : 'pending',
      dataSize: `${Math.floor(Math.random() * 100) + 10} KB`,
    };
  });
};

const BlockchainLedger = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [blocks] = useState(generateBlockchainData(20));
  const [selectedBlock, setSelectedBlock] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  const handleViewDetails = (block: any) => {
    setSelectedBlock(block);
    setDialogOpen(true);
  };
  
  const filteredBlocks = blocks.filter(block => {
    if (searchTerm) {
      return Object.values(block).some(val => 
        val.toString().toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    return true;
  });
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-2">
                <Database className="h-6 w-6 text-blockchain" />
                <h1 className="text-3xl font-bold">Blockchain Ledger</h1>
              </div>
              
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search blocks, hashes..." 
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                The blockchain ledger provides immutable records of all transactions processed by the system
              </p>
            </div>
            
            <Tabs defaultValue="blocks">
              <TabsList>
                <TabsTrigger value="blocks">Blocks</TabsTrigger>
                <TabsTrigger value="analytics">Blockchain Analytics</TabsTrigger>
              </TabsList>
              
              <TabsContent value="blocks">
                <Card>
                  <CardHeader>
                    <CardTitle>Transaction Blocks</CardTitle>
                    <CardDescription>
                      Immutable records secured by blockchain technology
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Block ID</TableHead>
                          <TableHead>Timestamp</TableHead>
                          <TableHead className="hidden md:table-cell">Hash (Short)</TableHead>
                          <TableHead className="hidden lg:table-cell">Transactions</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredBlocks.length > 0 ? (
                          filteredBlocks.map((block) => (
                            <TableRow key={block.id}>
                              <TableCell className="font-medium">{block.id}</TableCell>
                              <TableCell>{block.timestamp}</TableCell>
                              <TableCell className="hidden md:table-cell">{`${block.hash.substring(0, 10)}...`}</TableCell>
                              <TableCell className="hidden lg:table-cell">{block.txCount}</TableCell>
                              <TableCell>{block.userInfo}</TableCell>
                              <TableCell>{block.transactionType}</TableCell>
                              <TableCell>
                                <Badge variant={block.status === 'confirmed' ? 'default' : 'secondary'}>
                                  {block.status.charAt(0).toUpperCase() + block.status.slice(1)}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-right">
                                <Button size="sm" variant="outline" onClick={() => handleViewDetails(block)}>
                                  View
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-4">
                              No blocks found
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="analytics">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Blockchain Statistics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Total Blocks</span>
                          <span className="font-medium">24,815</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Total Transactions</span>
                          <span className="font-medium">186,329</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Average Block Time</span>
                          <span className="font-medium">15.2 seconds</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Chain Size</span>
                          <span className="font-medium">1.28 GB</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Current Difficulty</span>
                          <span className="font-medium">2,834,256</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Security Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Network Hash Rate</span>
                          <span className="font-medium">128.5 TH/s</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Consensus Nodes</span>
                          <span className="font-medium">156 Active</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Average Finality</span>
                          <span className="font-medium">2.8 seconds</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Validator Uptime</span>
                          <span className="font-medium">99.98%</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">Last Network Upgrade</span>
                          <span className="font-medium">2 days ago</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
      
      {selectedBlock && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Block Details</DialogTitle>
              <DialogDescription>
                Full information about block {selectedBlock.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Block ID</p>
                  <p>{selectedBlock.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Timestamp</p>
                  <p>{selectedBlock.timestamp}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-muted-foreground">Block Hash</p>
                <p className="font-mono text-xs overflow-x-auto break-all bg-muted p-2 rounded-md">
                  {selectedBlock.hash}
                </p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-muted-foreground">Previous Block Hash</p>
                <p className="font-mono text-xs overflow-x-auto break-all bg-muted p-2 rounded-md">
                  {selectedBlock.prevHash}
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Transaction Count</p>
                  <p>{selectedBlock.txCount}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">User Info</p>
                  <p>{selectedBlock.userInfo}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Transaction Type</p>
                  <p>{selectedBlock.transactionType}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge variant={selectedBlock.status === 'confirmed' ? 'default' : 'secondary'}>
                    {selectedBlock.status.charAt(0).toUpperCase() + selectedBlock.status.slice(1)}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Data Size</p>
                  <p>{selectedBlock.dataSize}</p>
                </div>
              </div>
            </div>
            
            <div className="mt-4">
              <Button variant="outline" className="w-full" onClick={() => setDialogOpen(false)}>
                Close
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default BlockchainLedger;
