
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { BarChart, LineChart, PieChart } from '@/components/ui/chart';
import { Activity, AlertTriangle, CheckCircle, DollarSign, TrendingDown, TrendingUp, Users } from 'lucide-react';

const Dashboard = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  // Sample data for charts
  const transactionData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Safe Transactions',
        data: [65, 59, 80, 81, 56, 55],
        fill: false,
        borderColor: '#48bb78',
      },
      {
        label: 'Suspicious Transactions',
        data: [28, 48, 40, 19, 86, 27],
        fill: false,
        borderColor: '#ed8936',
      },
      {
        label: 'Fraud Transactions',
        data: [10, 20, 15, 5, 12, 8],
        fill: false,
        borderColor: '#e53e3e',
      },
    ],
  };
  
  const fraudTypeData = {
    labels: ['Phishing', 'Identity Theft', 'Account Takeover', 'Payment Fraud', 'Other'],
    datasets: [
      {
        data: [30, 25, 15, 20, 10],
        backgroundColor: ['#48bb78', '#ed8936', '#e53e3e', '#2c7a7b', '#805ad5'],
      },
    ],
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <h1 className="text-3xl font-bold">Dashboard</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-l-4 border-l-safe">
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Safe Transactions</p>
                    <p className="text-3xl font-bold">2,845</p>
                    <p className="text-sm font-medium text-safe flex items-center gap-1">
                      <TrendingUp size={14} /> +12.5%
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-safe/10 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-6 w-6 text-safe" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-l-4 border-l-suspicious">
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Suspicious Transactions</p>
                    <p className="text-3xl font-bold">428</p>
                    <p className="text-sm font-medium text-suspicious flex items-center gap-1">
                      <TrendingUp size={14} /> +5.2%
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-suspicious/10 rounded-full flex items-center justify-center">
                    <AlertTriangle className="h-6 w-6 text-suspicious" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-l-4 border-l-fraud">
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Fraud Transactions</p>
                    <p className="text-3xl font-bold">142</p>
                    <p className="text-sm font-medium text-fraud flex items-center gap-1">
                      <TrendingDown size={14} /> -2.3%
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-fraud/10 rounded-full flex items-center justify-center">
                    <Activity className="h-6 w-6 text-fraud" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="border-l-4 border-l-blockchain">
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Amount Protected</p>
                    <p className="text-3xl font-bold">$348K</p>
                    <p className="text-sm font-medium text-blockchain flex items-center gap-1">
                      <TrendingUp size={14} /> +8.1%
                    </p>
                  </div>
                  <div className="h-12 w-12 bg-blockchain/10 rounded-full flex items-center justify-center">
                    <DollarSign className="h-6 w-6 text-blockchain" />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Transaction Overview</CardTitle>
                  <CardDescription>Monthly transaction volume by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <LineChart 
                    data={transactionData} 
                    className="aspect-[3/2] w-full"
                  />
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Fraud Type Distribution</CardTitle>
                  <CardDescription>Breakdown of detected fraud types</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center">
                  <PieChart 
                    data={fraudTypeData} 
                    className="aspect-square w-full max-w-[300px]"
                  />
                </CardContent>
              </Card>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
                <CardDescription>Latest system activities and events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[1, 2, 3, 4, 5].map((_, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        index % 3 === 0 ? 'bg-safe/10' : index % 3 === 1 ? 'bg-suspicious/10' : 'bg-fraud/10'
                      }`}>
                        {index % 3 === 0 ? (
                          <CheckCircle className="h-5 w-5 text-safe" />
                        ) : index % 3 === 1 ? (
                          <AlertTriangle className="h-5 w-5 text-suspicious" />
                        ) : (
                          <Activity className="h-5 w-5 text-fraud" />
                        )}
                      </div>
                      <div className="space-y-1">
                        <p className="font-medium">
                          {index % 3 === 0 ? 'Transaction Approved' : index % 3 === 1 ? 'Suspicious Activity Detected' : 'Fraud Alert Triggered'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {index % 3 === 0 ? 'Transaction #38291 was marked as safe' : 
                           index % 3 === 1 ? 'Multiple login attempts from different locations' : 
                           'Pattern matching indicates potential fraud in transaction #39148'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {index % 3 === 0 ? '2 minutes ago' : index % 3 === 1 ? '15 minutes ago' : '32 minutes ago'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
