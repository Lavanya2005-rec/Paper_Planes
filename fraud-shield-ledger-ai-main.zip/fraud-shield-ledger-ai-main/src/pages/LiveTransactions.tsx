
import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, Search, XCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';

// Mock data for transactions
const generateMockTransactions = (count: number) => {
  const statuses = ['safe', 'suspicious', 'fraud'];
  const names = ['John Smith', 'Sarah Johnson', 'Michael Brown', 'Emily Davis', 'David Wilson'];
  const locations = ['New York, US', 'London, UK', 'Tokyo, JP', 'Sydney, AU', 'Toronto, CA'];
  
  return Array(count).fill(0).map((_, i) => {
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    const riskScore = status === 'safe' ? Math.floor(Math.random() * 30) : 
                     status === 'suspicious' ? 30 + Math.floor(Math.random() * 40) : 
                     70 + Math.floor(Math.random() * 30);
    
    return {
      id: `TX-${100000 + i}`,
      name: names[Math.floor(Math.random() * names.length)],
      amount: `$${(Math.random() * 1000).toFixed(2)}`,
      time: new Date(Date.now() - Math.floor(Math.random() * 86400000)).toLocaleString(),
      location: locations[Math.floor(Math.random() * locations.length)],
      userId: `U-${10000 + Math.floor(Math.random() * 1000)}`,
      email: `user${i}@example.com`,
      username: `user${i}`,
      status,
      riskScore
    };
  });
};

const LiveTransactions = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [transactions] = useState(generateMockTransactions(20));
  const [selectedTransaction, setSelectedTransaction] = useState<any>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  const handleViewDetails = (transaction: any) => {
    setSelectedTransaction(transaction);
    setDialogOpen(true);
  };
  
  const handleFlagAsFraud = (transaction: any) => {
    toast.success(`Transaction ${transaction.id} marked as fraud`);
    setDialogOpen(false);
  };
  
  const handleBlock = (transaction: any) => {
    toast.success(`Transaction ${transaction.id} and user ${transaction.userId} blocked`);
    setDialogOpen(false);
  };
  
  const filteredTransactions = transactions.filter(tx => {
    // Filter by tab
    if (activeTab !== 'all' && tx.status !== activeTab) {
      return false;
    }
    
    // Filter by search term
    if (searchTerm && !Object.values(tx).some(val => 
      val.toString().toLowerCase().includes(searchTerm.toLowerCase())
    )) {
      return false;
    }
    
    return true;
  });
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <h1 className="text-3xl font-bold">Live Transactions</h1>
              <div className="flex items-center gap-2">
                <Select defaultValue="today">
                  <SelectTrigger className="w-36">
                    <SelectValue placeholder="Filter by time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="custom">Custom Range</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="destructive" size="sm">
                  Clear Data
                </Button>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab} value={activeTab}>
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="safe">Safe</TabsTrigger>
                  <TabsTrigger value="suspicious">Suspicious</TabsTrigger>
                  <TabsTrigger value="fraud">Fraud</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Search transactions..." 
                  className="pl-10 w-full sm:w-64"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <Card>
              <CardHeader className="pb-3">
                <CardTitle>Transaction Feed</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredTransactions.length > 0 ? (
                    filteredTransactions.map((tx) => (
                      <div 
                        key={tx.id} 
                        className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-4 rounded-lg border ${
                          tx.status === 'fraud' ? 'bg-fraud/5 border-fraud/20' :
                          tx.status === 'suspicious' ? 'bg-suspicious/5 border-suspicious/20' :
                          'bg-safe/5 border-safe/20'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                            tx.status === 'fraud' ? 'bg-fraud/10' :
                            tx.status === 'suspicious' ? 'bg-suspicious/10' :
                            'bg-safe/10'
                          }`}>
                            {tx.status === 'fraud' ? (
                              <XCircle className="h-5 w-5 text-fraud" />
                            ) : tx.status === 'suspicious' ? (
                              <AlertCircle className="h-5 w-5 text-suspicious" />
                            ) : (
                              <CheckCircle className="h-5 w-5 text-safe" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{tx.name}</p>
                              <Badge variant={
                                tx.status === 'fraud' ? 'destructive' :
                                tx.status === 'suspicious' ? 'outline' :
                                'default'
                              }>
                                {tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}
                              </Badge>
                            </div>
                            <div className="flex flex-col xs:flex-row gap-1 xs:gap-4 text-sm text-muted-foreground">
                              <p>ID: {tx.id}</p>
                              <p>{tx.amount}</p>
                              <p>Risk Score: {tx.riskScore}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                          {tx.status === 'fraud' ? (
                            <>
                              <Button size="sm" onClick={() => handleViewDetails(tx)}>Review Details</Button>
                              <Button size="sm" variant="destructive" onClick={() => handleBlock(tx)}>Block</Button>
                            </>
                          ) : tx.status === 'suspicious' ? (
                            <>
                              <Button size="sm" onClick={() => handleViewDetails(tx)}>Review Details</Button>
                              <Button size="sm" variant="destructive" onClick={() => handleFlagAsFraud(tx)}>Flag as Fraud</Button>
                            </>
                          ) : (
                            <Button size="sm" onClick={() => handleViewDetails(tx)}>Review Details</Button>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">No transactions found</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {selectedTransaction && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
              <DialogDescription>
                Full information about transaction {selectedTransaction.id}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid grid-cols-2 gap-4 py-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Transaction ID</p>
                <p>{selectedTransaction.id}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Status</p>
                <Badge variant={
                  selectedTransaction.status === 'fraud' ? 'destructive' :
                  selectedTransaction.status === 'suspicious' ? 'outline' :
                  'default'
                }>
                  {selectedTransaction.status.charAt(0).toUpperCase() + selectedTransaction.status.slice(1)}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p>{selectedTransaction.name}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Amount</p>
                <p>{selectedTransaction.amount}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Time</p>
                <p>{selectedTransaction.time}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Location</p>
                <p>{selectedTransaction.location}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">User ID</p>
                <p>{selectedTransaction.userId}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Email</p>
                <p>{selectedTransaction.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Username</p>
                <p>{selectedTransaction.username}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Risk Score</p>
                <p>{selectedTransaction.riskScore}/100</p>
              </div>
            </div>
            
            <DialogFooter>
              {selectedTransaction.status === 'fraud' ? (
                <Button variant="destructive" onClick={() => handleBlock(selectedTransaction)}>Block User</Button>
              ) : selectedTransaction.status === 'suspicious' ? (
                <Button variant="destructive" onClick={() => handleFlagAsFraud(selectedTransaction)}>Flag as Fraud</Button>
              ) : null}
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default LiveTransactions;
