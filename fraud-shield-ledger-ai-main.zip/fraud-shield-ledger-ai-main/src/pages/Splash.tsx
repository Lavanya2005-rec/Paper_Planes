
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo, LogoIcon } from '@/components/ui/logo';

const Splash = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const redirectTimer = setTimeout(() => {
      navigate('/login');
    }, 5000);

    return () => clearTimeout(redirectTimer);
  }, [navigate]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background">
      <div className="animate-fade-in flex flex-col items-center gap-8">
        <LogoIcon variant="large" animated={true} />
        <Logo variant="large" className="text-4xl" />
        <div className="mt-8 space-y-2 text-center">
          <p className="text-muted-foreground animate-pulse-slow">AI-powered fraud detection system</p>
          <div className="flex items-center gap-2 justify-center">
            <div className="h-2 w-2 rounded-full bg-safe animate-pulse"></div>
            <div className="h-2 w-2 rounded-full bg-suspicious animate-pulse delay-200"></div>
            <div className="h-2 w-2 rounded-full bg-fraud animate-pulse delay-500"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Splash;
