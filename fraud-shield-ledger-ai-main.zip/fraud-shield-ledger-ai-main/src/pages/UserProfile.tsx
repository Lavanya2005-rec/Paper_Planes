
import React, { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Navbar } from '@/components/layout/Navbar';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Camera, LogOut, Mail, Phone, User, LucideIcon, Shield, Bell, Lock } from 'lucide-react';

const ProfileItem = ({ icon: Icon, label, value, badge }: { icon: LucideIcon, label: string, value: string, badge?: string }) => {
  return (
    <div className="flex items-start gap-3 py-2">
      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        <div className="flex items-center gap-2">
          <p>{value}</p>
          {badge && <Badge variant="outline">{badge}</Badge>}
        </div>
      </div>
    </div>
  );
};

const UserProfile = () => {
  const [isDarkMode, setIsDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [isEditing, setIsEditing] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  
  const toggleTheme = () => {
    document.documentElement.classList.toggle('dark');
    setIsDarkMode(!isDarkMode);
  };
  
  const handleSaveProfile = () => {
    toast.success('Profile updated successfully');
    setIsEditing(false);
  };
  
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      toast.success('Profile picture uploaded');
    }
  };
  
  const handleToggleNotifications = (checked: boolean) => {
    setNotificationsEnabled(checked);
    toast.success(`Notifications ${checked ? 'enabled' : 'disabled'}`);
  };
  
  const handleToggleTwoFactor = (checked: boolean) => {
    setTwoFactorEnabled(checked);
    
    if (checked) {
      toast.success('Two-factor authentication enabled');
    } else {
      toast.error('Two-factor authentication disabled');
    }
  };
  
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar onThemeToggle={toggleTheme} isDarkMode={isDarkMode} />
        <main className="flex-1 overflow-y-auto p-6">
          <div className="space-y-6 max-w-4xl mx-auto">
            <div className="flex flex-col xs:flex-row justify-between items-start xs:items-center gap-4">
              <h1 className="text-3xl font-bold">User Profile</h1>
              <Button variant="destructive" size="sm" className="flex items-center gap-2">
                <LogOut className="h-4 w-4" /> Logout
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-1">
                <CardHeader>
                  <CardTitle>Personal Info</CardTitle>
                  <CardDescription>Your profile details and photo</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col items-center">
                  <div className="relative mb-4">
                    <Avatar className="h-24 w-24">
                      <AvatarImage src="https://images.unsplash.com/photo-1599566150163-29194dcaad36" />
                      <AvatarFallback className="text-xl">JD</AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-2 -right-2">
                      <Label htmlFor="profilePicture" className="cursor-pointer">
                        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                          <Camera className="h-4 w-4 text-primary-foreground" />
                        </div>
                        <Input 
                          id="profilePicture" 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={handleFileUpload} 
                        />
                      </Label>
                    </div>
                  </div>
                  
                  <h2 className="text-xl font-bold">John Doe</h2>
                  <p className="text-sm text-muted-foreground">Administrator</p>
                  
                  <Separator className="my-4" />
                  
                  <div className="w-full space-y-2">
                    <ProfileItem 
                      icon={User} 
                      label="Full Name" 
                      value="John Doe" 
                    />
                    <ProfileItem 
                      icon={Mail} 
                      label="Email" 
                      value="john.doe@example.com" 
                      badge="Verified" 
                    />
                    <ProfileItem 
                      icon={Phone} 
                      label="Phone" 
                      value="+1 (555) 123-4567" 
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="md:col-span-2">
                <Tabs defaultValue="account">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle>Account Settings</CardTitle>
                      <TabsList>
                        <TabsTrigger value="account">Account</TabsTrigger>
                        <TabsTrigger value="security">Security</TabsTrigger>
                        <TabsTrigger value="notifications">Notifications</TabsTrigger>
                      </TabsList>
                    </div>
                    <CardDescription>Manage your account settings and preferences</CardDescription>
                  </CardHeader>
                  
                  <TabsContent value="account" className="m-0">
                    <CardContent>
                      <div className="space-y-4">
                        {isEditing ? (
                          <form className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="fullName">Full Name</Label>
                              <Input id="fullName" defaultValue="John Doe" />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="email">Email</Label>
                              <Input id="email" defaultValue="john.doe@example.com" />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="phone">Phone</Label>
                              <Input id="phone" defaultValue="+1 (555) 123-4567" />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="role">Role</Label>
                              <Input id="role" defaultValue="Administrator" disabled />
                            </div>
                          </form>
                        ) : (
                          <div className="space-y-4">
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Account Type</p>
                              <div className="flex items-center gap-2">
                                <p className="font-medium">Administrator</p>
                                <Badge variant="outline">Super User</Badge>
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Account ID</p>
                              <p className="font-medium">A-10012345</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Created At</p>
                              <p className="font-medium">January 15, 2025</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-muted-foreground">Last Login</p>
                              <p className="font-medium">April 9, 2025 (Today) at 09:15 AM</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      {isEditing ? (
                        <>
                          <Button variant="outline" onClick={() => setIsEditing(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleSaveProfile}>Save Changes</Button>
                        </>
                      ) : (
                        <Button onClick={() => setIsEditing(true)}>Edit Profile</Button>
                      )}
                    </CardFooter>
                  </TabsContent>
                  
                  <TabsContent value="security" className="m-0">
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <Lock className="h-4 w-4 text-muted-foreground" />
                              <p className="font-medium">Password</p>
                            </div>
                            <p className="text-sm text-muted-foreground">Last changed 30 days ago</p>
                          </div>
                          <Button>Change Password</Button>
                        </div>
                        
                        <Separator />
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <Shield className="h-4 w-4 text-muted-foreground" />
                              <p className="font-medium">Two-factor Authentication</p>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {twoFactorEnabled ? 'Enabled' : 'Add an extra layer of security'}
                            </p>
                          </div>
                          <Switch 
                            checked={twoFactorEnabled} 
                            onCheckedChange={handleToggleTwoFactor} 
                          />
                        </div>
                        
                        <Separator />
                        
                        <div className="space-y-2">
                          <h3 className="font-medium">Login Sessions</h3>
                          <div className="space-y-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <p>Current Session</p>
                                <p className="text-sm text-muted-foreground">New York, United States</p>
                              </div>
                              <Badge>Active Now</Badge>
                            </div>
                            <div className="flex justify-between items-center">
                              <div>
                                <p>Chrome on Windows</p>
                                <p className="text-sm text-muted-foreground">1 day ago</p>
                              </div>
                              <Button variant="outline" size="sm">Log Out</Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button variant="destructive" className="w-full">Log Out of All Sessions</Button>
                    </CardFooter>
                  </TabsContent>
                  
                  <TabsContent value="notifications" className="m-0">
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <Bell className="h-4 w-4 text-muted-foreground" />
                              <p className="font-medium">Email Notifications</p>
                            </div>
                            <p className="text-sm text-muted-foreground">Receive email notifications about fraud alerts</p>
                          </div>
                          <Switch 
                            checked={notificationsEnabled} 
                            onCheckedChange={handleToggleNotifications} 
                          />
                        </div>
                        
                        <Separator />
                        
                        <div className="space-y-4">
                          <h3 className="font-medium">Notification Preferences</h3>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <Label htmlFor="fraud-alerts">Fraud Alerts</Label>
                              <Switch id="fraud-alerts" defaultChecked />
                            </div>
                            <div className="flex items-center justify-between">
                              <Label htmlFor="suspicious-activity">Suspicious Activity</Label>
                              <Switch id="suspicious-activity" defaultChecked />
                            </div>
                            <div className="flex items-center justify-between">
                              <Label htmlFor="system-updates">System Updates</Label>
                              <Switch id="system-updates" />
                            </div>
                            <div className="flex items-center justify-between">
                              <Label htmlFor="analytics-reports">Analytics Reports</Label>
                              <Switch id="analytics-reports" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">Save Notification Preferences</Button>
                    </CardFooter>
                  </TabsContent>
                </Tabs>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default UserProfile;
